
<?php

    class BlogUsers
    {
        public $firstName;
        public $lastName;
        public $email;


        public function __construct($firstName, $lastName, $email)
        {
            $this->firstName = $firstName;
            $this->lastName = $lastName;
            $this->email = $email;
        }

    }


    //valid users
    $blogUser1 = new BlogUsers( "Miguel","Pereira","pereira@gmail.com");
    $blogUser2 = new BlogUsers("Emanuelle","Pane","pane@gmail.com");
    $blogUser3 = new BlogUsers("Evelline","Sparreboom","sparreboom@gmail.com");
    $blogUser4 = new BlogUsers("Constant","Zomer","zomer@gmail.com");
    $blogUser5 = new BlogUsers("Eleni","Chrysomalli","chrysomall@gmail.com");


?>

