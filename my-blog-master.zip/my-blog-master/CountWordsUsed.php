<?php
require_once('classes.php');
require_once('getNewPost.php');

class CountWordsUsed
{

    //returns an array with all the words from the content from all the blog posts that have length longer than 4 letters
    public static function getPostsContent()
    {

        $contentWords = array();
        foreach($this->posts as $post)
        {
            $contentWords[]= $post-> getContentWords();
        }

        return $contentWords ;
    }

    //returns an array sorted by the times that each word is used
    public static function sortWordsOfContent($contentWords)
    {
        $popularWords = array();

//        returns an array using the values of contentWords as keys and their frequency in array as values &and then sort
//        values from higher to lower
        $popularWords []  = krsort (array_count_values( $contentWords ));
        return $popularWords ;
     }

}