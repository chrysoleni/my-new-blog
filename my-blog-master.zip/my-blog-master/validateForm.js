/**
*  Check input for valid email address.
* @param email
* @returns {boolean}
*/
function validateEmail(email)
{
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}

/**
 * Submit contact form validation
 */

function validateForm() {

    var errors = false;
    var title;
    var email;
    var content;


    //get the values of the field we want to check
    title = document.getElementById("title").value;
    email = document.getElementById("email").value;
    content = document.getElementById("content").value;

    //  Validations go here
    if (title.length < 1)
    {
        errors = true;
        alert("Name must be filled out");
    }
    else if (content.length < 1)
    {
        errors = true;
        alert("Content must be filled out");
    }
    else if (email.length < 1)
    {
        errors = true;
        alert("Email is empty or invalid");
    }
    // check if the email posted is valid
    else if (validateEmail(email) !== true)
    {
	    errors = true;
        alert("Email is invalid");
    }

    // If all the validations succeeded
    if (errors !== true)
    {
        return true;
    }
    else
    {
        return false;
    }
}

$(document).ready(function()
{
	$('#blogform').submit( function(event)
	{	
		isValid = validateForm();
		
		if (isValid)
		{
			alert('all good');
			$(this).unbind('submit');
		
			$(this).submit();
		}
		else
		{
			event.preventDefault();
			alert('ups');
		}
	});
});
