<?php
 //include 'blogPostsData.json';
 //include 'getNewPost.php';
?>

<html>
<head>
    <title>My spectacular Blog</title>
    <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.4.min.js"></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
    <script type="text/javascript" src="validateForm.js"></script>
    <link rel="stylesheet" type="text/css" href="theme.css">
</head>
<body>
<div class="wrapper">
    <div class="border">
        <h1>My spectacular Blog</h1>
        <h3>A totally false statement</h3>
        <form id="blogform" action="getNewPost.php" method="post">
            <div class="form-border">
                <div id="left" >
                    <p class="bold">New Blog Post</p>
                    <input type="text" name="title" id="title" placeholder="My blog title" size="53">
                    <input type="text" name="content" id="content" class="bigText" placeholder="Here all my important post text!" size="53" >
                    <input type="text" name="email" id="email" placeholder="Email adress" size="53">
                </div>
                <div id ="right">
                    <br><br>
                    <input id="submitbutton" type="submit" name="submit" value="submit">
            	</div>
            </div>
        </form>
    </div>

    <div class ="left-column">
        <?php
        	// process the template view for the blog posts
        	include('theme-blog-posts.php');
        ?>
    </div>        
</div>

    </body>
</html>

