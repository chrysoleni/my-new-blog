<?php


    class BlogPost
    {

        public $title;
        public $content;
        //public $image = array();
        public $email;
        public $datePosted ;


         public function __construct($title, $content, $email)
         {
            $this->title = $title;
            $this->content =$content ;
            $this->email = $email;

         }

          //returns an array with the words form the content with length longer that 4
        public function getContentWords($content)
        {
            $words = array();
            $contentWords = array();

            //get an array with all the words from the content
            $words[] = str_word_count($content,1);

             //then we check which of them have length longer than 4 chars
            foreach ($words as $word)
            {
                if (strlen($word)>4)
                {
                    $contentWords[]=$word ;
                }
            }

        return $contentWords;

        }



}
