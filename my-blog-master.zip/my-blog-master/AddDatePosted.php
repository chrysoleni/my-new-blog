<?php

    class AddDatePosted
    {
        //get the current timestamp
        public static function getDatePosted()
        {
            $date = new DateTime('now', new DateTimeZone('Europe/Amsterdam'));
            $datePosted = $date->getTimestamp();
            return $datePosted;
        }
    }