<?php
require_once ('BlogUsers.php');
require_once ('BlogPost.php');
require_once ('AddDatePosted.php');
//require_once('classes.php');
//require_once('blogPostsData.json');

// Initialize error as blank
$error = false;

//Get data from submitted form : title,content email
//
 if (isset($_POST["submit"]))
 {
         // removing extra white spaces & escaping harmful characters
         $title =trim($_POST['title']);
         $content = trim($_POST['content']) ;
         $email = trim($_POST['email']);

        //create an array with the emails of the valid users
    	$usersEmail = array (
            $blogUser1->email,
            $blogUser2->email,
            $blogUser3->email,
            $blogUser4->email,
            $blogUser5->email
        );

		if ( in_array( $email, $usersEmail ) )
		{
			//Create a new blogPost
            $newBlogPost = new BlogPost($title,$content,$email);

            //attach a timestamp
            $newBlogPost->datePosted = addDatePosted :: getDatePosted();

            //get the file that previous posts are stored
            $file ='blogPostsData.json';

            //get the content of the file
            $file_content = (file_get_contents($file));

            //decode it from json format
            $posts = json_decode($file_content, true);

            //add the new blog post to our post collection
            if ( is_array( $posts ) || empty($posts) )
            {
                $posts[] = $newBlogPost ;
            }

            //encode it
            $blog_post_json = json_encode($posts);

            //store it back to the file
            $ret = file_put_contents('blogPostsData.json', $blog_post_json);
            //echo "$ret bytes written to file. ";
            $error = false;

            //add the words in the array with the rest words from content
            //$contentWords= CountWordsUsed :: getPostsContent();

            //sort the array based on the popularity of each word
            //$popularWords = CountWordsUsed :: sortWordsOfContent($contentWords);
		}
        else
        {
        	$error = true;
        }

         // if there is error, do not process further
         if ( $error == true)
         {
             exit("There was an error writing this file : The ".$email." does not belong to a valid user");
         }
         else
         {
         	echo("<script type=\"text/javascript\">location.href = 'index.php';</script>");
         }
     }

 else
 {
     die('no post data to process');
 }