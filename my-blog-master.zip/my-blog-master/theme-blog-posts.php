<?php

//require_once ('classes.php');
//require_once ('getNewPost.php');
//require_once ('blogPostsData.json');

//Read the entire file into a string using file_get_contents
    $file = file_get_contents('blogPostsData.json');

    //Json decode to oject
    $posts = json_decode($file, true);

    //read JSON data for blog posts
    if (is_array($posts))
    {
        foreach ($posts as $post)
        {
            echo '<div class="border">';
            echo '<h3>'.$post['title'].'</h3>     <h4>'.$post['datePosted'].'</h4>';
            echo '<p>'.$post['content'].'</p>';
            echo '</div>';
        }
    }
?>
    <div class="right-colum">
		<ul>
            <?php
                for ($i=0; $i <= 4; $i++)
                {
                    echo '<li>'.$popularWords[$i]. '</li>';
                }
            ?>
        </ul>
    </div>